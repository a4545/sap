sap.ui.define([
	"sap/ui/model/json/JSONModel"
], function (JSONModel) {
	"use strict";
	return {
		getSampleData: function () {
			var oModel = new JSONModel("https://jsonplaceholder.typicode.com/users");
			console.log("my model is here", oModel);
			return oModel;
		}
	};

});