sap.ui.define([
	"demo/ui5/Myfirstsapapp/test/unit/controller/App.controller"
], function () {
	"use strict";
});