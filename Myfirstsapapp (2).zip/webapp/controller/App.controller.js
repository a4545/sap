sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function (Controller,MessageToast) {
	"use strict";

	return Controller.extend("demo.ui5.Myfirstsapapp.controller.App", {
		handleUploadComplete: function(oEvent) {
			console.log(oEvent)
			
			var sResponse = oEvent.getParameter("status");
			console.log(sResponse);
			if (sResponse) {
				var sMsg = "";
				// var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
				// console.log(m)
				if (sResponse == "200") {
					sMsg = "Return Code: " + sResponse + "\n" + sResponse + "(Upload Success)";
					oEvent.getSource().setValue("");
				} else {
					sMsg = "Return Code: " +" error" +"\n" +" error"+ "(Upload Error)";
				}

				MessageToast.show(sMsg);
			}
		},

		handleUploadPress: function(oEvent) {
			var oFileUploader = this.byId("fileUploader");
	// var x=new sap.ui.unified.FileUploader(oFileUploader);
//console.log(new sap.ui.unified.FileUploaderParameter(oFileUploader));
          
			oFileUploader.upload();
		}
	});
});